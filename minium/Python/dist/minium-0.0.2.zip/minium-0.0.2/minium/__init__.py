#!/usr/bin/env python3
from.wechatdriver.minium import Minium,build_version
from.wechatdriver.page import Page
from.wechatdriver.app import App
from.wechatdriver.element import BaseElement
from.framework.minitest import MiniTest
__version__="0.0.1"
# Created by pyminifier (https://github.com/liftoff/pyminifier)
